public class Token {
    String VP;
    String CP;
    int line;

    public Token(String VP, String CP,int line) {
        this.VP = VP;
        this.CP = CP;
        this.line=line;
    }

    public String toString() {
        return formateOutPut(CP, VP);
    }
    String formateOutPut(String l,String t){
        String outPut=l;
        for(int i=l.length() ; i<16 ; i++){
            outPut+=' ';
        }
        return outPut+ VP +"\t \t"+line;
    }

}